#!/usr/bin/env bash
# Usage: ./build_ollama.sh /path/to/your_hf_model_folder my-slm
# Needs: git, python3, pip, and Ollama installed.
set -e
MODEL_DIR="${1:?Give the path to your Hugging Face-format model folder}"
NAME="${2:-my-slm}"

if [ ! -d llama.cpp ]; then
  git clone https://github.com/ggerganov/llama.cpp
  pip install -r llama.cpp/requirements.txt
fi

# 1) Convert HF weights -> GGUF (f16)
python3 llama.cpp/convert_hf_to_gguf.py "$MODEL_DIR" --outfile model.gguf --outtype f16

# 2) Create the Ollama model
ollama create "$NAME" -f Modelfile

echo "Done. Run it with:  ollama run $NAME"
