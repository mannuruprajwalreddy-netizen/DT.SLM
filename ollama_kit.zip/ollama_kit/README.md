# Ollama kit for your SLM

Files
- Modelfile        : Ollama config (edit the TEMPLATE/SYSTEM to match how you trained the model)
- build_ollama.sh  : converts your model to GGUF and registers it in Ollama

Steps
1. Install Ollama: https://ollama.com/download
2. Make sure your model is saved in Hugging Face format
   (model.save_pretrained("my_slm") and tokenizer.save_pretrained("my_slm")).
3. Run:  ./build_ollama.sh ./my_slm my-slm
4. Chat: ollama run my-slm

Already have a .gguf file? Rename it to model.gguf, put it beside the Modelfile,
and just run:  ollama create my-slm -f Modelfile

Optional: smaller file with quantization
  ./llama.cpp/build/bin/llama-quantize model.gguf model-q4.gguf Q4_K_M
  then change FROM in the Modelfile to ./model-q4.gguf

Note: llama.cpp only converts architectures it supports (Llama, GPT-2, Qwen, Gemma, Phi, etc.).
A fully custom architecture needs a custom converter.
